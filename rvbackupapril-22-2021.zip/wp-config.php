<?php
define('WP_AUTO_UPDATE_CORE', 'minor');// This setting is required to make sure that WordPress updates can be properly managed in WordPress Toolkit. Remove this line if this WordPress website is not managed by WordPress Toolkit anymore.
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wp_o27oc' );

/** MySQL database username */
define( 'DB_USER', 'wp_nenax' );

/** MySQL database password */
define( 'DB_PASSWORD', '^d$~Lb6ErRV5JYs9' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost:3306' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY', '9%fNV7UK82X!VP;Vt|Q_BK#uSs6KY2hRnJsAgl]67A#79PR927CMKitX2-E|Y2u+');
define('SECURE_AUTH_KEY', '/QoQhWk3&EDBed0hh_(vl_BWOb-hAgei%w!/yhS|sv0cSt*9/4R~O%U;#P;FJi;/');
define('LOGGED_IN_KEY', 'TY7DLq[%&1@47NH~a[]P@/p2*-W!36p)U9iO[RB#334&TODBGb0w4fK53t~14VfU');
define('NONCE_KEY', 'u:bWMbp98aB:@+3w[g7l~5e27DaJTVL|kR81l7Jw_k@1mz)f0nj8|Xd&63EPp+[a');
define('AUTH_SALT', '6lx44*0[0B!8N61zz/MaFe_TA~a!F705rRwpnu]o9;:hXTvmD(J1IjV2L7[TxyTY');
define('SECURE_AUTH_SALT', '2p(&bd|D(oM35!dqJ9YI:e1Qg&+9VOx@d_![RM@[L-2|:qR-/46*@~hr%CuhoOq-');
define('LOGGED_IN_SALT', 'p1s%h8wBbb[hBMp/o_3y25E)0Z]4(j0:4Pp:iNL2L%8v8F(me8IQA-111N!2SKA3');
define('NONCE_SALT', '9Is9Q2)Drt|[c:vR38!-3(vbCe5+p8-5k*2!56Q)m::bJ9L(2//9]01HYis!e4UA');

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'eDp32xW8_';


define('WP_ALLOW_MULTISITE', true);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) )
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
